require(['notebook/js/codecell'], function(codecell) {
  //codecell.CodeCell.options_default.highlight_modes['text/x-octave'] = {'reg':[/^%%dlv/]} ;
  codecell.CodeCell.options_default.highlight_modes['prolog'] = {'reg':[/^%%clingo/]} ;
  Jupyter.notebook.events.one('kernel_ready.Kernel', function(){
  Jupyter.notebook.get_cells().map(function(cell){
      if (cell.cell_type == 'code'){ cell.auto_highlight(); } }) ;
  });
});

require(['notebook/js/codecell'], function (codecell) {
  codecell.CodeCell.options_default.highlight_modes['magic_sql'] = {
    reg: ["^%%sql"]
  };
  Jupyter.notebook.events.one('kernel_ready.Kernel', function(){
  Jupyter.notebook.get_cells().map(function(cell){
      if (cell.cell_type == 'code'){ cell.auto_highlight(); } }) ;
  });
});
