import os
import re
from datetime import datetime, timedelta
import pytz
import sys
import shutil

def parse_cmd():
    if '-a' not in sys.argv:
        raise ValueError('Provide assignment name with -a option')
    if '-d' not in sys.argv:
        raise ValueError('Provide due date UTC in format %Y_%m_%m_%H_%M with -d option')
    move = '-m' in sys.argv

    assign_name_index = sys.argv.index('-a') + 1
    if assign_name_index >= len(sys.argv) or sys.argv[assign_name_index].startswith('-'):
        raise ValueError('Assignment name cannot be blank.')
    assign_name = sys.argv[assign_name_index]
    
    due_date_index = sys.argv.index('-d') + 1
    if due_date_index >= len(sys.argv) or sys.argv[due_date_index].startswith('-'):
        raise ValueError('Due date cannot be blank.')

    due_time = datetime.strptime(sys.argv[due_date_index], '%Y_%m_%d_%H_%M')
    due_time = due_time.replace(tzinfo=pytz.utc)
    return assign_name, due_time, move



late_submission_buffer_mins = 5 # Allows late submissions of upto 5 minutes.
assign_name, due_time, move = parse_cmd()

course_name = 'datacleaning'
exchg_inbound_dir = '/srv/nbgrader/exchange/%s/inbound' % course_name
late_submissions_dir = '/srv/nbgrader/exchange/%s/late_submissions/%s' % (course_name, assign_name)


dir_matching_regex = r'(.+)\+(%s)\+(.+)' % assign_name # file name of the format 'netid+assignname+timestamp'
assgn_dirs = [os.path.join(exchg_inbound_dir, f) for f in os.listdir(exchg_inbound_dir) if re.match(dir_matching_regex, f) and os.path.isdir(os.path.join(exchg_inbound_dir, f))]

# List files that were submitted post due date
def late_submission(dir_name):
    timestamp_file = os.path.join(dir_name, 'timestamp.txt')
    if not os.path.exists(timestamp_file):
        raise ValueError('Timestamp file missing: %s' % timestamp_file)
    with open(timestamp_file, 'r') as f:
        submission_time = f.read()
    # Remove UTC timezone from the end.
    submission_time = ' '.join(submission_time.split(' ')[0:2])
    submission_time = datetime.strptime(submission_time, '%Y-%m-%d %H:%M:%S.%f')
    submission_time = submission_time.replace(tzinfo=pytz.utc)
    return (submission_time - due_time) > timedelta(minutes = late_submission_buffer_mins)


late_submissions = [f for f in assgn_dirs if late_submission(f)]

print('\nFollowing are late submissions.')
for l in late_submissions:
    print(l)

if move:
    bkp_dir = os.path.join(exchg_inbound_dir, '..', 'inbound.bkp.' + datetime.strftime(datetime.now(), '%Y_%d_%m_%H_%M_%S'))
    print('\nBefore moving late submissions, taking backup of the entire inbound directory.')
    print("Backing up %s to %s" % (exchg_inbound_dir, bkp_dir))
    shutil.copytree(exchg_inbound_dir, bkp_dir)
    print()
    if not os.path.exists(late_submissions_dir):
        os.makedirs(late_submissions_dir)
    print("Moving late submissions to %s" % late_submissions_dir)
    for l in late_submissions:
        shutil.move(l, late_submissions_dir)
    

