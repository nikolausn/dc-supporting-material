# This code can be put in any Python module, it does not require IPython
# itself to be running already.  It only creates the magics subclass but
# doesn't instantiate it yet.
from __future__ import print_function
from IPython.core.magic import (Magics, magics_class, line_magic,
                                cell_magic, line_cell_magic)

# The class MUST call this class decorator at creation time
@magics_class
class PlainTextMagics(Magics):

    # This class is used to read arbitrary text from some cell in the notebook.
    # This will be used to read student's regex or dlv or sql.
    
    def __init__(self, unique_name, shell=None,  **kwargs):
        super(PlainTextMagics, self).__init__(shell=shell, **kwargs)
        self.store = []
        # Put it in user namespace.
        # Make sure that unique_name is not overriding something in user ns. Use some prefix before name
        shell.user_ns[unique_name] = self.store

    def cmagic(self, line, cell):
        cell_contents = self.get_cell_contents(cell) # get cell contents as a list. Each line is a new member of list.
        return self.store.append((line, cell_contents))

    
    def get_cell_contents(self, cell):
        return [s.strip() for s in cell.splitlines() if not s.strip().startswith('#')]


