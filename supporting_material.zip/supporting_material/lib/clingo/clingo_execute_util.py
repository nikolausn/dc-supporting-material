import os
import re
from sys import platform

from ..shell import shell_util

import uuid
import io

def run_clingo(clingo_script_abs_path):
    command = ['clingo', '--verbose=0', clingo_script_abs_path]
    ret_code, stdout, stderr = shell_util.execute(command)
    return ret_code, stdout.decode("utf-8"), stderr.decode("utf-8")

def save_and_run_clingo(clingo_lp):
    # Write to tmp file. dlv binary only works with files and doesn't take commands from stdin.
    unique_filename = os.path.join('/tmp', str(uuid.uuid4()) + '.lp')
    with open(unique_filename, 'w+') as f:
        f.write(clingo_lp)

    try:
        # Execute.
        ret_code, stdout, stderr = run_clingo(unique_filename)
        return unique_filename, ret_code, stdout, stderr
    finally:
        # Delete the tmp file.
        os.remove(unique_filename)

def sorted_predicates_list(clingo_output):
    return sorted(clingo_output.split(' '))

def extract_solution_from_stdout(clingo_stdout):
    return clingo_stdout.split('\n')[0]

