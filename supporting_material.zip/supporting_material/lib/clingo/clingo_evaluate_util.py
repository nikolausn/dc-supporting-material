from .clingo_magic import *
from . import clingo_execute_util as ce

def clingo_evaluate(db_file, lp, predicate_name, predicate_arity, expected_output, display_output=True):
    augmented_lp = augment_lp(lp, db_file, predicate_name, predicate_arity)
    tmp_file_name, ret_code, stdout, stderr = ce.save_and_run_clingo(augmented_lp)
    # if ret_code == 0:
    if ret_code == 30:
        stdout = ce.extract_solution_from_stdout(stdout.strip())
        expected_output_l = ce.sorted_predicates_list(expected_output.strip())
        actual_output_l = ce.sorted_predicates_list(stdout)
        passed = expected_output_l == actual_output_l
        if passed:
            display_success_msg(["Test passed."])
            if(display_output):
                display_success_msg(["Your output matched with following expected output:"])
                display(PrologCodeSnippet((expected_output)))
        else:
            display_error_msg(["Test failed. Expected output didn't match with actual output.", "Actual output:"])
            display(PrologCodeSnippet((stdout)))
            if(display_output):
                display_error_msg(["Expected output:"])
                display(PrologCodeSnippet((expected_output)))
        assert passed
    else:
        display_error_msg(['An error occured while running clingo.', stderr, stdout])
        if tmp_file_name in stderr:
          display_error_msg(['Above clingo snippet was saved to temp file %s. Line numbers shown below.' % tmp_file_name])
        display(PrologCodeSnippet((augmented_lp)))
        raise AssertionError