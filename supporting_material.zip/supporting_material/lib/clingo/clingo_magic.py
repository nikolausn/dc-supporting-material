# This code can be put in any Python module, it does not require IPython
# itself to be running already.  It only creates the magics subclass but
# doesn't instantiate it yet.
from IPython.core.magic import (Magics, magics_class, line_magic,
                                cell_magic, line_cell_magic)
from IPython.display import display
from pygments import highlight
from pygments.lexers import PrologLexer
from pygments.formatters import HtmlFormatter
from IPython.core.display import HTML


import enum, os, re, json

from . import clingo_execute_util as ce

# The class MUST call this class decorator at creation time
@magics_class
class ClingoMagics(Magics):
    # This class is used to read clingo from some cell in the notebook.

    CLINGO_EVALUATE_EXPECTED_OUTPUT_KEY = 'expected_output'

    def __init__(self, shell=None,  **kwargs):
        super(ClingoMagics, self).__init__(shell=shell, **kwargs)
        self.shell = shell
        self.db_file = None

    @line_magic
    def set_db_file(self, lp_file_path):
        lp_file_path = lp_file_path or ''
        if not os.path.isfile(lp_file_path):
          raise IOError('No such file: %s' % lp_file_path)
        self.db_file =  lp_file_path
        with open(lp_file_path, 'r') as f:
          display(PrologCodeSnippet(f.read()))

    @line_magic
    def reset_db_file(self):
        self.db_file = None


    @cell_magic('clingo')
    def execute(self, args, lp=''):
        lp = remove_nbgrader_delimiters(lp)
        result_var, predicate_name, predicate_arity = parse_args(args)
        augmented_lp = augment_lp(lp, self.db_file, predicate_name, predicate_arity)
        tmp_file_name, ret_code, stdout, stderr = \
            ce.save_and_run_clingo(augmented_lp)

        # if ret_code == 0:
        if ret_code == 30:
            result = PrologCodeSnippet(ce.extract_solution_from_stdout(stdout))
            if result_var is not None:
              print("Saving output to local variable {}['result']".format(result_var))
              print("Saving code snippet to local variable {}['code']".format(result_var))
              result_and_codesnippet = {'result' : result, 'code' : PrologCodeSnippet(lp)}
              self.shell.user_ns.update({result_var: result_and_codesnippet})
            return result
        else:
            display_error_msg(['An error occured while running clingo.', stderr, stdout])
            if tmp_file_name in stderr:
              display_error_msg(['Your clingo snippet was saved to temp file %s. Line numbers shown below.' % tmp_file_name])
              display(PrologCodeSnippet(augmented_lp))



def remove_nbgrader_delimiters(lp):
    return '\n'.join([l for l in lp.split("\n") if not l.startswith("###")])

def parse_args(args):
    args = args or '{}'
    args = json.loads(args)
    return args.get('result_var'), args.get('predicate'), args.get('predicate_arity')

def augment_lp(lp, db_file, predicate_name, predicate_arity):
        lp_modified = []
        if (db_file):
            lp_modified.append('#include "{}".'.format(db_file))
        lp_modified.append(lp)
        if (predicate_name and predicate_arity):
            lp_modified.append('#show {}/{}.'.format(predicate_name, predicate_arity))
        return '\n'.join(lp_modified)

class PrologCodeSnippet(str):
    def __new__(self, descriptor):
      if os.path.isfile(descriptor):
        with open(descriptor, 'r') as f:
          tmp_str = f.read()
      else:
        tmp_str = descriptor
      tmp_str = tmp_str.strip()
      return super(PrologCodeSnippet, self).__new__(self, tmp_str)

    def _repr_html_(self):
      display(HTML("""
      <style>
      {pygments_css}
      </style>
      """.format(pygments_css=HtmlFormatter().get_style_defs('.highlight'))))
      if len(self.splitlines()) > 1:
        return HTML(data=highlight(self, PrologLexer(), HtmlFormatter(linenos='inline')))._repr_html_()
      else:
        return HTML(data=highlight(self, PrologLexer(), HtmlFormatter()))._repr_html_()


def display_error_msg(err_msgs):
    display_msg(err_msgs, "#AF1C1C")

def display_success_msg(success_msgs):
    display_msg(success_msgs, "green")

def display_info_msg(success_msgs):
    display_msg(success_msgs, "#163399")

def display_msg(msgs, color):
    msg = "<br/>".join(msgs)
    display(HTML('<p><font color="%s">%s</font></p>' % (color, msg)))




# In order to actually use these magics, you must register them with a
# running IPython.
def load_ipython_extension(ipython):
    """
    Any module file that define a function named `load_ipython_extension`
    can be loaded via `%load_ext module.path` or be configured to be
    autoloaded by IPython at startup time.
    """
    # You can register the class itself without instantiating it.  IPython will
    # call the default constructor on it.
    ipython.register_magics(ClingoMagics)
