# This code can be put in any Python module, it does not require IPython
# itself to be running already.  It only creates the magics subclass but
# doesn't instantiate it yet.
from IPython.core.magic import (Magics, magics_class, line_magic,
                                cell_magic, line_cell_magic)
from IPython.display import display
from IPython.core.display import HTML
import os

from .metadata_reader import JSONMetadataReader
from .sqlite_evaluate_util import cmp_select_output_with_csv
from .prettytable_csv import PrettyTableCsvReader

def get_expected_output_file(problem_name):
	expected_output_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../data/sqlite/expected_output')
	if problem_name is None:
		problem_name = ''
	return os.path.join(expected_output_dir, problem_name.strip() + '.csv')

def get_database_file(problem_name):
	database_files_dir = os.path.join(os.path.abspath(__file__), '../../data/sqlite/db')

@magics_class
class SqlEvaluateMagics(Magics):
    

    def __init__(self, shell=None,  **kwargs):
        super(SqlEvaluateMagics, self).__init__(shell=shell, **kwargs)
        # For each problem we are keeping track of dlv commands.
        # Further more, dlv commands for each problem are divided into two groups, visible and hidden from students.
        # For each problem, think of maintaining two dlv files, one hidden and one visible.
        # The visible commands go to the hidden file but not other way around.

        self.shell = shell
        self.mr = JSONMetadataReader('grading_config.json')

    @line_magic
    def sql_expected_output(self, problem_name):
        problem_name = (problem_name or '').strip()
        expected_output_file = self.mr.expected_output_file_path(problem_name)
        if expected_output_file is not None:
          return PrettyTableCsvReader(expected_output_file) 
        else:
          print("Invalid problem name %s." % problem_name)

    @line_magic
    def sql_evaluate(self, problem_name):
        problem_name = (problem_name or '').strip()
        if problem_name not in self.shell.user_ns or 'query' not in self.shell.user_ns[problem_name]:
          display_error_msg(["No query found for problem %s." % problem_name])
          assert False, "No query found for problem %s." % problem_name
        else:
          problem_query = self.shell.user_ns[problem_name]['query']

        expected_output_file = self.mr.expected_output_file_path(problem_name)
        database_file = self.mr.database_path(problem_name)
        if expected_output_file is not None and database_file is not None:
          res_match = cmp_select_output_with_csv(expected_output_file, database_file, problem_query, self.mr.sort_before_comparison(problem_name))
          if res_match:
            display_success_msg(["Test passed."])
          else:
            display_error_msg(["Test failed.", "Output didn't match with expected output."])
            assert res_match 
        else:
          display_error_msg(["Invalid problem name %s." % problem_name])
          assert False, 'Invalid problem name: %s' % problem_name
    


def display_error_msg(err_msgs):
    display_msg(err_msgs, "#AF1C1C")

def display_success_msg(success_msgs):
    display_msg(success_msgs, "green")

def display_info_msg(success_msgs):
    display_msg(success_msgs, "#163399")

def display_msg(msgs, color):
    msg = "<br/>".join(msgs)
    display(HTML('<p><font color="%s">%s</font></p>' % (color, msg)))


# In order to actually use these magics, you must register them with a
# running IPython.
def load_ipython_extension(ipython):
    """
    Any module file that define a function named `load_ipython_extension`
    can be loaded via `%load_ext module.path` or be configured to be
    autoloaded by IPython at startup time.
    """
    # You can register the class itself without instantiating it.  IPython will
    # call the default constructor on it.
    ipython.register_magics(SqlEvaluateMagics)
