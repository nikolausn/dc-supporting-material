import re
import csv
import prettytable

def unduplicate_field_names(field_names):
    """Append a number to duplicate field names to make them unique. """
    res = []
    for k in field_names:
        if k in res:
            i = 1
            while k + '_' + str(i) in res:
                i += 1
            k += '_' + str(i)
        res.append(k)
    return res


def _nonbreaking_spaces(match_obj):
    """
    Make spaces visible in HTML by replacing all `` `` with ``&nbsp;``

    Call with a ``re`` match object.  Retain group 1, replace group 2
    with nonbreaking speaces.
    """
    spaces = '&nbsp;' * len(match_obj.group(2))
    return '%s%s' % (match_obj.group(1), spaces)

_cell_with_spaces_pattern = re.compile(r'(<td>)( {2,})')


class PrettyTableCsvReader(list):

  def __init__(self, csv_file_path):
    temp_list = []
    with open(csv_file_path, 'r') as f:
      temp_list = list(csv.reader(f))
    
    if len(temp_list) > 0:
      self.field_names = unduplicate_field_names(temp_list[0])
    else:
      self.field_names = []

    if len(temp_list) > 1:
      list.__init__(self, temp_list[1:])
    else:
      list.__init__(self, [])

    self.pretty = prettytable.PrettyTable(self.field_names, style='DEFAULT')
    for row in self:
      for i in range(len(row)):
            e = row[i]
            if len(e.strip()) == 0:
                row[i] = None
      self.pretty.add_row(row)

    
  def _repr_html_(self):
    _cell_with_spaces_pattern = re.compile(r'(<td>)( {2,})')
    result = self.pretty.get_html_string()
    result = _cell_with_spaces_pattern.sub(_nonbreaking_spaces, result)
    return result
    
