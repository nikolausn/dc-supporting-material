import json
import operator
import os


class MetadataReader(object):
    def database_path(self, problem_name):
        raise NotImplementedError("This method must be implemented.")

    def expected_output_file_path(self, problem_name):
        raise NotImplementedError("This method must be implemented.")

    def sort_before_comparison(self, problem_name):
        raise NotImplementedError("This method must be implemented.")


class JSONMetadataReader(MetadataReader):
    __databases_dir_key = "databases_dir"
    __expected_output_dir_key = "expected_output_dir"
    __problems_key = "problems"
    __database_file_key = "database_file"
    __sort_before_comparison_key = "sort"
    __expected_output_file_suffix = ".csv"


    def __init__(self, json_file_path):
        # File path should either be absolute or relative to the path of current python file.
        json_file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), json_file_path)
        with open(json_file_path) as jc_file:
            self.grading_config = json.load(jc_file)

    def database_path(self, problem_name,data_path=None):
        if problem_name not in self.grading_config[self.__problems_key]:
            return None
        database_dir = self.grading_config[self.__databases_dir_key]
        database_file = self.grading_config[self.__problems_key][problem_name][self.__database_file_key]
        database_path = os.path.join(database_dir, database_file)
        return self.__resolve_path(database_path,data_path)

    def expected_output_file_path(self, problem_name, data_path=None):
        if problem_name not in self.grading_config[self.__problems_key]:
            return None
	
        expected_output_dir = self.grading_config[self.__expected_output_dir_key]
        expected_output_file = problem_name + self.__expected_output_file_suffix
        expected_output_file_path = os.path.join(expected_output_dir, expected_output_file)
        return self.__resolve_path(expected_output_file_path,data_path)

    def sort_before_comparison(self, problem_name):
        return self.grading_config[self.__problems_key][problem_name][self.__sort_before_comparison_key]

    @staticmethod
    def __resolve_path(path,data_path=None):
        #(path,data_path)
        if data_path == None:
         return os.path.join(os.path.expanduser('~/data_readonly/'), 'sqlite', path)
        return os.path.join(data_path, 'sqlite', path)
