ipython -c "import nose; nose.run()"
