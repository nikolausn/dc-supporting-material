import os
import shutil

user_home = '/home/{username}'
user_feedback_dir = os.path.join(user_home, 'feedback', '{assignment_name}')
global_feedback_dir = os.path.join('/home/bbassi2/datacleaning_assignments_nbgrader/feedback')
global_assignment_feedback_dir = os.path.join(global_feedback_dir, '{username}', '{assignment_name}')


def user_exists(username):
    # Checks if user exists.
    return os.path.isdir(user_home.format(**{'username' : username}))

def feedback_for_user_exists(username, assignment_name):
    return os.path.isdir(global_assignment_feedback_dir.format(**{'username' : username, 'assignment_name' : assignment_name}))


def copy_feedback_to_student(assignment_name):
    # This copies feedback from global feedback directory to student's home.
    users = [d for d in os.listdir(global_feedback_dir) if os.path.isdir(os.path.join(global_feedback_dir, d))]
    for user in users:
        if user_exists(user):
            if feedback_for_user_exists(user, assignment_name):
                src_feedback_dir = global_assignment_feedback_dir.format(**{'username': user, 'assignment_name' : assignment_name})
                dstn_feedback_dir = user_feedback_dir.format(**{'username' : user, 'assignment_name' : assignment_name})
                if os.path.isdir(dstn_feedback_dir):
                    print("Deleting existing directory %s" % dstn_feedback_dir)
                    shutil.rmtree(dstn_feedback_dir)
                print("Copying from %s to %s" % (src_feedback_dir, dstn_feedback_dir))
                shutil.copytree(src_feedback_dir, dstn_feedback_dir)
            else:
                print("Feedback for assignment %s for user %s doesn't exist." % (assignment_name, user))
        else:
            print("Invalid user %s." % user)

copy_feedback_to_student("regex")

