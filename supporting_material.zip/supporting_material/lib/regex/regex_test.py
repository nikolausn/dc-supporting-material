import re

def match_test_case(regex, test_case, ignore_case):
    assert len(regex.strip()) > 0, "Regex cannot be empty."
    
    if ignore_case:
        return regex, re.fullmatch(regex, test_case, re.I)
    else:
        return regex, re.fullmatch(regex, test_case)
    
def test_positive(regex, positive_test_case, ignore_case=False):
    regex_c, match = match_test_case(regex, positive_test_case, ignore_case)
    match_error_msg = "Regex %s didn't match %s" % (regex_c, positive_test_case)
    if match:
        print('Test passed.')
    else:
        matched_substrings = partial_matches(regex, positive_test_case, ignore_case)
        if matched_substrings:
            print("Test failed. However your regular expression matched partially.")
            print("Matched substrings: %s" % matched_substrings)
        else:
            print("Test failed.")
    assert match, match_error_msg

def test_negative(regex, negative_test_case, ignore_case=False):
    regex_c, match = match_test_case(regex, negative_test_case, ignore_case)
    match_error_msg = "Regex %s wrongly matched %s" % (regex_c, negative_test_case)
    if not match:
        print("Test passed.")
    else:
        print("Test failed.")
    assert not match, match_error_msg
              

def partial_matches(regex, test_case, ignore_case):
    if ignore_case:
        return re.findall(regex, test_case, re.I)
    else:
        return re.findall(regex, test_case)
              
              
