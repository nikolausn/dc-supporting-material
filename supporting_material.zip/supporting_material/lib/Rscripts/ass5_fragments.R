library(stringr)

test.packages <- function(packName) {
  result <- FALSE
  x <- search()
  y <- str_detect(x,regex(packName,ignore_case=TRUE))
  for (i in 1:length(y)) {
    if(y[i] == TRUE) {
      result <- TRUE
      break
    }
  }
  return(result)
}